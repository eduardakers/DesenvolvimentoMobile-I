# Conversor de Moeda
App de conversão de moeda com Kotlin usando Retrofit. Esse app foi criado para demonstrar como consumir APIs utilizando a lib do Retrofit. Para melhor utilizar esse repositório veja juntamente com este [vídeo](https://www.youtube.com/watch?v=U3Nmw0_BMVs)
